export class Admin {
    aId:number;
    fName:string;
    lName:string;
    phoneNo:number;
    userName:string;
    password:string;
}
