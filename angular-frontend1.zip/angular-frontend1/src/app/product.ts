export class Product {
    pId:number;
    image:string;
    pName:string;
    qty:number;
    uQty:number;
    price:number;
}
