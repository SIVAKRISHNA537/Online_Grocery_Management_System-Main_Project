export class Payment {
 payId:number;
 name:string;
 address:string;
 phoneNo:string;
 cardNo:string;
 paymentType:string;
 totalAmount:string;
 customer:Payment;
}
