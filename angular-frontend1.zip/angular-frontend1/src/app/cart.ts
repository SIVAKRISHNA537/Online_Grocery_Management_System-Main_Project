export class Cart {
    cartId:number;
    pId:number;
    image:String;
    pName:String;
    qty:number;
    price:number;
    total:number
}
