export class Customer {
    cId:number;
    fName:string;
    lName:string;
    phoneNo:string;
    address:string;
    userName:string;
    password:string;
}
